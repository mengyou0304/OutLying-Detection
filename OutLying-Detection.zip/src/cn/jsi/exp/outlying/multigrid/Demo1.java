package cn.jsi.exp.outlying.multigrid;

public class Demo1 {

}
